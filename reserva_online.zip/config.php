<?php 
//connect BD login
$bd = mysql_connect('mysql.hostinger.es','u507863943_yei','123456');
//select BD user
$select = mysql_select_db('u507863943_bd', $bd);
 ?>